import React, { useState, useRef } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { TextInput, Button, Text, useTheme } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { db, storage } from './firebase';
import { collection, addDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import QRCode from 'react-native-qrcode-svg';
import * as FileSystem from 'expo-file-system';
import ViewShot from 'react-native-view-shot';
import { auth } from './firebase'; // Import the auth object
import { createUserWithEmailAndPassword } from 'firebase/auth';

export default function AddEmployeeScreen() {
  const theme = useTheme();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [category, setCategory] = useState('Employee');
  const viewShotRef = useRef(null);

  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validateContactNumber = (contactNumber) => /^\d{10}$/.test(contactNumber);
  const validatePassword = (password) => /^(?=.*[!@#$%^&])[A-Za-z\d@$!%*?&]{8,}$/.test(password);

  const handleAddEmployee = async () => {
    setError('');
    setSuccess('');

    if (!name) {
      setError('Name is required.');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address.');
      return;
    }

    if (!validateContactNumber(contactNumber)) {
      setError('Contact number must be 10 digits.');
      return;
    }

    if (!validatePassword(password)) {
      setError('Password must be at least 8 characters long and include a special character.');
      return;
    }

    try {



    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const userId = userCredential.user.uid; // Get the user ID

      if (viewShotRef.current) {
        // Capture the QR code as a Base64 image
        const uri = await viewShotRef.current.capture();
        const base64Code = await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        console.log(uri);


        if (!base64Code) {
          setError("Failed to extract Base64 data from QR code.");
          return;
        }

        const fileUri = FileSystem.cacheDirectory + `${name}.png`;
        await FileSystem.writeAsStringAsync(fileUri, base64Code, {
          encoding: FileSystem.EncodingType.Base64,
        });

        // Upload the QR code image file to Firebase
        const storageRef = ref(storage, `qrcodes/${name}.png`);
        const imgBlob = await (await fetch(fileUri)).blob();
        await uploadBytes(storageRef, imgBlob);

        const qrCodeURL = await getDownloadURL(storageRef);

        // Add employee data to Firestore
        await addDoc(collection(db, 'employees'), {
          Username: name,
          Email: email,
          Contact: contactNumber,
          Password: password,
          QrCodeURL: qrCodeURL,
          category: category,
          userId:userId
        });

        setSuccess('Employee added successfully!');
        setName('');
        setEmail('');
        setContactNumber('');
        setPassword('');
      } else {
        setError("QR code view reference is not available.");
      }
    } catch (error) {
      setError("Failed to save or upload QR code: " + error.message);
    }
  };

  return (
    <LinearGradient colors={['#FF8C00', '#FF6347']} style={styles.background}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Add Employee</Text>

        <TextInput
          label="Name"
          value={name}
          onChangeText={setName}
          style={styles.input}
          mode="outlined"
          placeholder="Enter employee name"
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        <TextInput
          label="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.input}
          mode="outlined"
          placeholder="Enter employee email"
          keyboardType="email-address"
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        <TextInput
          label="Contact Number"
          value={contactNumber}
          onChangeText={setContactNumber}
          style={styles.input}
          mode="outlined"
          placeholder="Enter contact number"
          keyboardType="phone-pad"
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        <TextInput
          label="Password"
          value={password}
          onChangeText={setPassword}
          style={styles.input}
          mode="outlined"
          placeholder="Enter password"
          secureTextEntry
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        {success ? <Text style={styles.successText}>{success}</Text> : null}

        <Button
          mode="contained"
          onPress={handleAddEmployee}
          style={styles.button}
          labelStyle={styles.buttonLabel}
        >
          Add Employee
        </Button>

        {/* QR Code section wrapped in ViewShot for capturing */}
        <ViewShot ref={viewShotRef} options={{ format: 'png', quality: 1.0 }}>
          <QRCode value={name || 'DefaultText'} size={256} />
        </ViewShot>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: { flex: 1 },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#fff', textAlign: 'center' },
  input: { width: '100%', marginBottom: 15, backgroundColor: 'transparent' },
  button: { marginVertical: 10, paddingVertical: 5, backgroundColor: '#6200ee', width: '100%' },
  buttonLabel: { fontSize: 18, color: '#fff' },
  errorText: { color: 'red', textAlign: 'center', marginBottom: 10 },
  successText: { color: 'green', textAlign: 'center', marginBottom: 10 },
});
