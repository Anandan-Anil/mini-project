import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TextInput, FlatList, Text, ActivityIndicator } from 'react-native';
import { db } from './firebase'; // Import your Firebase setup
import { collection, getDocs } from 'firebase/firestore';

export default function AttendanceScreen() {
  const [search, setSearch] = useState('');
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAllAttendanceRecords = async () => {
    try {
      setLoading(true);
      const allRecords = [];

      console.log("Fetching all user documents...");

      // Fetch all users
      const usersSnapshot = await getDocs(collection(db, 'attendance'));
      console.log(usersSnapshot);
      
      
      // Iterate over each user document
      for (let userDoc of usersSnapshot.docs) {
        const userId = userDoc.id; // Get the user ID
        
        // Now, fetch attendance records for each user by accessing their date subcollections
        const attendanceQuerySnapshot = await getDocs(collection(db, `attendance/${userId}`));
        console.log("hiiiiiiii",attendanceQuerySnapshot);
        
        
        attendanceQuerySnapshot.forEach(async (dateDoc) => {
          const dateId = dateDoc.id; // The date subcollection ID
          const attendanceRecordsSnapshot = await getDocs(collection(db, `attendance/${userId}/${dateId}`));
          
          attendanceRecordsSnapshot.forEach((attendanceDoc) => {
            const attendanceData = attendanceDoc.data();
            console.log(`Attendance data found for user ${userId} on ${dateId}: ${JSON.stringify(attendanceData)}`);
            
            // Fetch employee data based on the userId
            const employeeData = fetchEmployeeData(userId);
            allRecords.push({
              id: attendanceDoc.id,
              userId,
              ...attendanceData,
              employeeName: employeeData?.Username || 'Unknown',
            });
          });
        });
      }

      setAttendanceRecords(allRecords);
      setFilteredRecords(allRecords);
      console.log("All attendance records fetched:", allRecords);
    } catch (error) {
      console.error("Error fetching attendance records:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployeeData = async (userId) => {
    try {
      console.log(`Fetching employee data for userId: ${userId}`);
      const employeeQuery = query(collection(db, 'employees'), where('userId', '==', userId));
      const employeeSnapshot = await getDocs(employeeQuery);
      
      if (!employeeSnapshot.empty) {
        const employeeData = employeeSnapshot.docs[0].data();
        console.log(`Employee data found for userId ${userId}: ${JSON.stringify(employeeData)}`);
        return employeeData; // Return the employee data directly
      } else {
        console.log(`No employee data found for userId ${userId}`);
        return null;
      }
    } catch (error) {
      console.error("Error fetching employee data:", error);
      return null;
    }
  };

  useEffect(() => {
    fetchAllAttendanceRecords();
  }, []);

  useEffect(() => {
    const results = attendanceRecords.filter(record =>
      record.employeeName.toLowerCase().includes(search.toLowerCase()) ||
      record.firstScanTime?.includes(search) ||
      record.secondScanTime?.includes(search) ||
      record.attendanceStatus.toLowerCase().includes(search.toLowerCase())
    );
    setFilteredRecords(results);
  }, [search, attendanceRecords]);

  const renderAttendanceItem = ({ item }) => (
    <View style={styles.recordItem}>
      <Text style={styles.recordText}>Employee: {item.employeeName}</Text>
      <Text style={styles.recordText}>First Scan: {item.firstScanTime || 'N/A'}</Text>
      <Text style={styles.recordText}>Second Scan: {item.secondScanTime || 'N/A'}</Text>
      <Text style={styles.recordText}>Status: {item.attendanceStatus}</Text>
    </View>
  );

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Search Attendance"
        value={search}
        onChangeText={setSearch}
        style={styles.searchInput}
      />
      <FlatList
        data={filteredRecords}
        renderItem={renderAttendanceItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  searchInput: {
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  listContainer: {
    paddingBottom: 100,
  },
  recordItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  recordText: {
    fontSize: 16,
  },
});
