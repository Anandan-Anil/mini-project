import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { TextInput, Button, Text, useTheme } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { db } from './firebase'; // Import Firestore
import { collection, addDoc } from 'firebase/firestore'; 

export default function AddEmployeeScreen() {
  const theme = useTheme();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validateContactNumber = (contactNumber) => /^\d{10}$/.test(contactNumber);
  const validatePassword = (password) => /^(?=.*[!@#$%^&*])[A-Za-z\d@$!%*?&]{8,}$/.test(password);

  const handleAddEmployee = async () => {
    setError('');
    setSuccess('');

    if (!name) {
      setError('Name is required.');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address.');
      return;
    }

    if (!validateContactNumber(contactNumber)) {
      setError('Contact number must be 10 digits.');
      return;
    }

    if (!validatePassword(password)) {
      setError('Password must be at least 8 characters long and include a special character.');
      return;
    }

    try {
      // Add employee data to Firestore
      await addDoc(collection(db, 'employees'), {
        Username:name,
        Email:email,
        Contact:contactNumber,
        Password:password,
      });

      setSuccess('Employee added successfully!');
      // Reset form
      setName('');
      setEmail('');
      setContactNumber('');
      setPassword('');
    } catch (error) {
      setError('Failed to add employee: ' + error.message);
    }
  };

  return (
    <LinearGradient colors={['#FF8C00', '#FF6347']} style={styles.background}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Add Employee</Text>

        <TextInput
          label="Name"
          value={name}
          onChangeText={setName}
          style={styles.input}
          mode="outlined"
          placeholder="Enter employee name"
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        <TextInput
          label="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.input}
          mode="outlined"
          placeholder="Enter employee email"
          keyboardType="email-address"
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        <TextInput
          label="Contact Number"
          value={contactNumber}
          onChangeText={setContactNumber}
          style={styles.input}
          mode="outlined"
          placeholder="Enter contact number"
          keyboardType="phone-pad"
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        <TextInput
          label="Password"
          value={password}
          onChangeText={setPassword}
          style={styles.input}
          mode="outlined"
          placeholder="Enter password"
          secureTextEntry
          theme={{ colors: { text: theme.colors.primary, placeholder: theme.colors.primary } }}
        />

        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        {success ? <Text style={styles.successText}>{success}</Text> : null}

        <Button
          mode="contained"
          onPress={handleAddEmployee}
          style={styles.button}
          labelStyle={styles.buttonLabel}
        >
          Add Employee
        </Button>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: { flex: 1 },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#fff', textAlign: 'center' },
  input: { width: '100%', marginBottom: 15, backgroundColor: 'transparent' },
  button: { marginVertical: 10, paddingVertical: 5, backgroundColor: '#6200ee', width: '100%' },
  buttonLabel: { fontSize: 18, color: '#fff' },
  errorText: { color: 'red', textAlign: 'center', marginBottom: 10 },
  successText: { color: 'green', textAlign: 'center', marginBottom: 10 },
});
